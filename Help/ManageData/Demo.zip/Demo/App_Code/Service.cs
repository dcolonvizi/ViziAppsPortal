﻿using System;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;
using System.Xml;
using System.Collections;

[WebService(Namespace = "http://mobiflex.mobi/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
// To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
// [System.Web.Script.Services.ScriptService]
public class Service : System.Web.Services.WebService
{
    public Service () {

        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
    }

    [WebMethod]
    public XmlDocument OneValueResponse(string input)
    {
        string error_message;
        XmlDocument doc = new XmlDataDocument();
        XmlNode top = doc.CreateNode(XmlNodeType.Element, "response", "");
        try
        {
            doc.AppendChild(top);
            AddNode(doc, top, "item", input);
            AddNode(doc, top, "status", "OK");

        }
        catch (Exception ex)
        {
            error_message = ex.Message + ": " + ex.StackTrace;
            AddNode(doc, top, "status", error_message);
        }
        return doc;

    }

    [WebMethod]
    public XmlDocument OneDimensionArrayResponse(string input)
    {
        string error_message;
        XmlDocument doc = new XmlDataDocument();
        XmlNode top = doc.CreateNode(XmlNodeType.Element, "response", "");
        try
        {
            doc.AppendChild(top);

            ArrayList array = new ArrayList();
            array.Add(input + " aaa");
            array.Add(input + " bbb");
            array.Add(input + " ccc");
            foreach (string value in array)
            {
                 AddNode(doc, top, "array", value);
            }

            AddNode(doc, top, "status", "OK");

        }
        catch (Exception ex)
        {
            error_message = ex.Message + ": " + ex.StackTrace;
            AddNode(doc, top, "status", error_message);
        }
        return doc;

    }
    [WebMethod]
    public XmlDocument TwoDimensionArrayResponse(string input)
    {
        string error_message;
        XmlDocument doc = new XmlDataDocument();
        XmlNode top = doc.CreateNode(XmlNodeType.Element, "response", "");
        try
        {
            doc.AppendChild(top);

            SortedList table = new SortedList();
            table["aaa"] = input + " xxx";
            table["bbb"] = input + " yyy";
            table["ccc"] = input + " zzz";

            int index = 1;
            foreach (string key in table.Keys)
            {
                XmlNode arrayNode = AddNode(doc, top, "array" + index.ToString());
                AddNode(doc, arrayNode, "dim1",key);
                AddNode(doc, arrayNode, "dim2", table[key].ToString());
                index++;
            }

            AddNode(doc, top, "status", "OK");

        }
        catch (Exception ex)
        {
            error_message = ex.Message + ": " + ex.StackTrace;
            AddNode(doc, top, "status", error_message);
        }
        return doc;

    }
    [WebMethod]
    public XmlDocument ThreeDimensionArrayResponse(string input)
    {
        string error_message;
        XmlDocument doc = new XmlDataDocument();
        XmlNode top = doc.CreateNode(XmlNodeType.Element, "response", "");
        try
        {
            doc.AppendChild(top);

            SortedList table = new SortedList();
            table["aaa"] = input + " xxx";
            table["bbb"] = input + " yyy";
            table["ccc"] = input + " zzz";

            int index = 1;
            foreach (string key in table.Keys)
            {
                XmlNode arrayNode = AddNode(doc, top, "array" + index.ToString());
                AddNode(doc, arrayNode, "dim1", index.ToString());
                AddNode(doc, arrayNode, "dim2", key);
                AddNode(doc, arrayNode, "dim3", table[key].ToString());
                index++;
            }

            AddNode(doc, top, "status", "OK");

        }
        catch (Exception ex)
        {
            error_message = ex.Message + ": " + ex.StackTrace;
            AddNode(doc, top, "status", error_message);
        }
        return doc;

    }
    private void AddNode(XmlDocument doc, XmlNode parent, string node_name, string value_string)
    {
        XmlNode node = doc.CreateNode(XmlNodeType.Element, node_name, "");
        node.InnerText = value_string;
        parent.AppendChild(node);
    }
    private XmlNode AddNode(XmlDocument doc, XmlNode parent, string node_name)
    {
        XmlNode node = doc.CreateNode(XmlNodeType.Element, node_name, "");
        parent.AppendChild(node);
        return node;
    }
}
