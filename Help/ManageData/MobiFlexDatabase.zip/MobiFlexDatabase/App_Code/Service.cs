﻿using System;
using System.Web;
using System.Web.UI;
using System.Web.Services;
using System.Web.Services.Protocols;
using System.Xml;
using System.IO;
using System.Data.Odbc;
using System.Text;
using System.Collections;


[WebService(Namespace = "http://mobiflex.me/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
// To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
// [System.Web.Script.Services.ScriptService]
public class Service : System.Web.Services.WebService
{
    public Service () {
        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
    }

    [WebMethod(EnableSession = true)]
    public XmlDocument DatabaseInterface(string database_type, string connection_string, 
        string schema, string event_commands)
    {
        XmlDocument doc = new XmlDataDocument();
        XmlNode top = doc.CreateNode(XmlNodeType.Element, "result","");
        doc.AppendChild(top);

        XmlDocument InputDoc = new XmlDocument();
        XmlDocument Schema = new XmlDocument();
        string error_message;

        if (database_type.Length == 0)
        {
            error_message = "No database_type input.";
            AddNode(doc, top, "status", error_message);
            return doc;
        }

        if (connection_string.Length == 0)
        {
            error_message = "No connection_string input.";
            AddNode(doc, top, "status", error_message);
            return doc;
        }

        if (schema.Length == 0)
        {
            error_message = "No schema input.";
            AddNode(doc, top, "status", error_message);
            return doc;
        }

        if (event_commands.Length == 0)
        {
            error_message = "No event_commands input.";
            AddNode(doc, top, "status", error_message);
            return doc;
        }

         try
        {
            Schema.LoadXml(schema);
            InputDoc.LoadXml(event_commands);
          
            OdbcConnection DbConnection = new OdbcConnection(connection_string);
            try
            {
                DbConnection.Open();
            }
            catch (OdbcException ex)
            {
                error_message = "Connection to the DSN '" + connection_string + "' failed. The OdbcConnection returned the following message: " +
                        ex.Message;
                AddNode(doc, top, "status", error_message);
                return doc;
            }
            XmlNode event_node = InputDoc.SelectSingleNode("//event");

            XmlNodeList sql_commands = InputDoc.SelectNodes("//sql_commands/sql_command");
            foreach (XmlNode sql_command in sql_commands)
            {
                OdbcCommand DbCommand = DbConnection.CreateCommand();
                OdbcParameterCollection parameters = DbCommand.Parameters;

                StringBuilder command_text = new StringBuilder();

                string command = sql_command.SelectSingleNode("command").InnerText;
                string table = sql_command.SelectSingleNode("table").InnerText;

                XmlNodeList fields = sql_command.SelectNodes("field_item");
                ArrayList field_array = new ArrayList();
                ArrayList value_array = new ArrayList();
                foreach (XmlNode field_item in fields)
                {
                    if (field_item.InnerXml.Length == 0)
                        continue;
                    field_array.Add(field_item.SelectSingleNode("database_field").InnerText);
                    value_array.Add(field_item.SelectSingleNode("phone_field").InnerText);
                }

                bool is_first = true;
                int index = 0;
                switch (command.ToLower())
                {
                    case "select from":
                        command_text.Append("SELECT ");
                        is_first = true;
                        foreach (string field in field_array)
                        {
                            if (is_first)
                                is_first = false;
                            else
                                command_text.Append(", ");
                            command_text.Append(field);
                        }
                        command_text.Append(" FROM " + table);
                        break;
                    case "insert into":
                        command_text.Append("INSERT INTO " + table + " ( ");
                        is_first = true;
                        index = 0;
                        foreach (string field in field_array)
                        {
                            if (is_first)
                                is_first = false;
                            else
                                command_text.Append(", ");
                            command_text.Append(field);
                        }
                        command_text.Append(") VALUES (");
                        foreach (string field in field_array)
                        {
                            if (is_first)
                                is_first = false;
                            else
                                command_text.Append(", ");
                            command_text.Append("?");
                            CreateParameter(parameters, Schema, field, value_array[index++].ToString());
                        }
                        command_text.Append(")");


                        break;
                    case "update":
                        command_text.Append("UPDATE " + table + " SET ");
                        is_first = true;
                        index = 0;
                        foreach (string field in field_array)
                        {
                            if (is_first)
                                is_first = false;
                            else
                                command_text.Append(", ");
                            command_text.Append(field + "=?");

                            CreateParameter(parameters, Schema, field, value_array[index++].ToString());
                        }
                        break;
                    case "delete from":
                        command_text.Append("DELETE FROM " + table);
                        break;
                }

                XmlNodeList conditions = sql_command.SelectNodes("condition");
                if (conditions != null && conditions.Count > 0)
                {
                    command_text.Append(" ");
                    foreach (XmlNode condition in conditions)
                    {
                        if (condition.InnerXml.Length == 0)
                            continue;
                        command_text.Append(condition.SelectSingleNode("condition_operation").InnerText + " ");
                        command_text.Append(condition.SelectSingleNode("condition_1st_field").InnerText + " ");
                        command_text.Append(condition.SelectSingleNode("field_operation").InnerText + " '");
                        command_text.Append(condition.SelectSingleNode("condition_2nd_field").InnerText + "'");
                    }
                }

                XmlNode order_by = sql_command.SelectSingleNode("order_by");
                if (order_by != null && order_by.InnerXml.Length > 0)
                {
                    command_text.Append(" ORDER BY " + order_by.SelectSingleNode("sort_field").InnerText);
                    if(order_by.SelectSingleNode("sort_direction").InnerText == "Ascending")
                        command_text.Append(" ASC");
                    else
                        command_text.Append(" DESC");
                }

                DbCommand.CommandText = command_text.ToString();
                OdbcDataReader DbReader = null;
                try
                {
                    DbReader = DbCommand.ExecuteReader();
                    // rest of the code to process the result set
                }
                catch (OdbcException ex)
                {
                    error_message = "Executing the query '" + command_text.ToString() +
                        "' failed. The OdbcCommand returned the following message: " + ex.Message;
                    AddNode(doc, top, "status", error_message);
                    return doc;
                }
                int fCount = DbReader.FieldCount;
                if (fCount > 0)
                {
                    XmlNode output = AddNode(doc, top, "output");
                    while (DbReader.Read())
                    {
                        XmlNode row = AddNode(doc, output, "select_row");
                        for (int i = 0; i < fCount; i++)
                        {
                            string field = DbReader.GetName(i);

                            if (GetOdbcType(Schema, field) == OdbcType.Image)
                            {
                                 byte[] b_value = (byte[])DbReader.GetValue(i);
                                 string folder_path = Server.MapPath("./image_files") ;
                                 string[] files = Directory.GetFiles(folder_path);
                                 foreach (string file in files)
                                 {
                                     if (File.GetLastWriteTime(file) < DateTime.Now.AddMinutes(-2.0D))
                                         File.Delete(file);
                                 }
                                 string file_path = folder_path + @"\" + field + ".jpg";
                                 File.WriteAllBytes(file_path, b_value);
                                 string http_path = Context.Request.Url.AbsoluteUri.Replace("Service.asmx","image_files/" + field + ".jpg");
                                 AddNode(doc, row, field, http_path);                                
                            }
                            else
                                AddNode(doc, row, field, DbReader.GetString(i));
                        }
                    }
                }
                DbReader.Close();
                DbCommand.Dispose();
            }

            DbConnection.Close();
            AddNode(doc, top, "status", "success");

        }
        catch (Exception ex)
        {
            error_message = ex.Message + ": " + ex.StackTrace;
            AddNode(doc, top, "status", error_message);
        }
        return doc;

    }
    private void CreateParameter(OdbcParameterCollection parameters, XmlDocument Schema, string field,
        string value)
    {
        OdbcType odbc_type = GetOdbcType(Schema, field);
        OdbcParameter parm = new OdbcParameter(field,odbc_type );

        XmlNode field_node = Schema.SelectSingleNode("//fields/field/name[.='" + field + "']");
        if (field_node.ParentNode.SelectSingleNode("length") != null)
        {
            string size = field_node.ParentNode.SelectSingleNode("length").InnerText;
            parm.Size = Convert.ToInt32(size);
        }

        parameters.Add(parm);
        if (odbc_type == OdbcType.Image)
        {
            byte[] bytes = (byte[]) Session[field];
             parameters[field].Value = bytes;
        }
        else
            parameters[field].Value = value;
        return;
    }
    private OdbcType GetOdbcType(XmlDocument Schema, string field)
    {
        XmlNode field_node = Schema.SelectSingleNode("//fields/field/name[.='" + field + "']");
        if (field_node != null)
        {
            string type = field_node.ParentNode.SelectSingleNode("type").InnerText;
            switch (type.ToLower())
            {
                case "bigint":
                    return OdbcType.BigInt;

                case "binary":
                    return OdbcType.Binary;

                case "bit":
                    return OdbcType.Bit;

                case "char":
                    return OdbcType.Char;

                case "year":
                case "date":
                    return OdbcType.Date;

                case "datetime":
                    return OdbcType.DateTime;

                case "decimal":
                    return OdbcType.Decimal;

                case "double":
                    return OdbcType.Double;

                case "blob":
                case "tinyblob":
                case "smallblob":
                case "mediumblob":
                case "longblob":
                    return OdbcType.Image;

                case "mediumint":
                case "int":
                    return OdbcType.Int;

                case "nchar":
                    return OdbcType.NChar;

                case "ntext":
                    return OdbcType.NText;

                case "numeric":
                    return OdbcType.Numeric;

                case "nvarchar":
                    return OdbcType.NVarChar;

                case "float":
                case "real":
                    return OdbcType.Real;

                case "smalldatetime":
                    return OdbcType.SmallDateTime;

                case "smallint":
                    return OdbcType.SmallInt;

                case "tinytext":
                case "text":
                case "mediumtext":
                case "longtext":
                    return OdbcType.Text;

                case "time":
                    return OdbcType.Time;

                case "timestamp":
                    return OdbcType.Timestamp;

                case "tinyint":
                    return OdbcType.TinyInt;

                case "uniqueidentifier":
                    return OdbcType.UniqueIdentifier;

                case "varbinary":
                    return OdbcType.VarBinary;

                case "varchar":
                    return OdbcType.VarChar;

            }
        }
        return OdbcType.VarChar;
    }
    private void AddNode(XmlDocument doc, XmlNode parent, string node_name, string value_string)
    {
        XmlNode node = doc.CreateNode(XmlNodeType.Element, node_name, "");
        node.InnerText = value_string;
        parent.AppendChild(node);
    }
    private XmlNode AddNode(XmlDocument doc, XmlNode parent, string node_name)
    {
        XmlNode node = doc.CreateNode(XmlNodeType.Element, node_name, "");
        parent.AppendChild(node);
        return node;
    }
}
