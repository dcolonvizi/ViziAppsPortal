﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.IO;

public partial class UploadImage : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        // Create a Stream object.
        System.IO.Stream sin = Request.InputStream;
        // Find number of bytes in stream.
        int strLen = Convert.ToInt32(sin.Length);
        // Create a byte array.
        byte[] data = new byte[strLen];
        sin.Read(data, 0, strLen);
        string field_name = Request.Headers["From"].ToString();
        Session[field_name] = data;
    }
    /*
     * byte[] myImageBytes = byteArrayFromDatabase;
Response.OutputStream.Write(myImageBytes, 0, myImageBytes.Length;
Response.Flush();
*/
}
